# Blood-Bank
Blood Bank website (Frontend perspective)


## Built with

* HTML - CSS - Bootstrap - Javascript

* JQuery - SwiperJs - FontAwesome


## Screens

https://www.behance.net/gallery/85230265/Blood-Bank-Website
